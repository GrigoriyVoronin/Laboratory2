﻿namespace Rivals
{
	public enum MapCell
	{
		Wall,
		Empty
	}
}